create function encrypt_client() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.address = project.encrypt(NEW.address);
    NEW.card_name = project.encrypt(NEW.card_name);
    NEW.card_number = project.encrypt(NEW.card_number);
    NEW.cvv = project.encrypt(NEW.cvv);
    NEW.expiry_date = project.encrypt(NEW.cvv);
    RETURN NEW;
END;
$$;

alter function encrypt_client() owner to dev;

