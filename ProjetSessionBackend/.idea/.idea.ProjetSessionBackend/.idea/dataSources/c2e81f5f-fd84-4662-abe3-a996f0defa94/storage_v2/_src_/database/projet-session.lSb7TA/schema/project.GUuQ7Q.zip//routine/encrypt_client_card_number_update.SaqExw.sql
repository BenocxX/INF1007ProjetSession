create function encrypt_client_card_number_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.card_number = project.encrypt(NEW.card_number);
    RETURN NEW;
END;
$$;

alter function encrypt_client_card_number_update() owner to dev;

