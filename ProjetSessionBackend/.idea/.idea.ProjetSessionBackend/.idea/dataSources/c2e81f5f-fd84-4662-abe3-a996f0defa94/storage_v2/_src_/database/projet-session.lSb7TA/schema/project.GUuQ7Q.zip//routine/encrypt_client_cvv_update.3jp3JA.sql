create function encrypt_client_cvv_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.cvv = project.encrypt(NEW.cvv);
    RETURN NEW;
END;
$$;

alter function encrypt_client_cvv_update() owner to dev;

