create function encrypt_client_address_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.address = project.encrypt(NEW.address);
    RETURN NEW;
END;
$$;

alter function encrypt_client_address_update() owner to dev;

