create function encrypt_client_expiry_date_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.expiry_date = project.encrypt(NEW.expiry_date);
    RETURN NEW;
END;
$$;

alter function encrypt_client_expiry_date_update() owner to dev;

