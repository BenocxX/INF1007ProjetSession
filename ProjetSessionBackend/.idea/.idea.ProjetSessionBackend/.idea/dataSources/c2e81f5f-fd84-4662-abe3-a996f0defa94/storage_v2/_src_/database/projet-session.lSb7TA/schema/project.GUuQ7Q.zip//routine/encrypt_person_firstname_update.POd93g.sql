create function encrypt_person_firstname_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.firstname = project.encrypt(NEW.firstname);
    RETURN NEW;
END;
$$;

alter function encrypt_person_firstname_update() owner to dev;

