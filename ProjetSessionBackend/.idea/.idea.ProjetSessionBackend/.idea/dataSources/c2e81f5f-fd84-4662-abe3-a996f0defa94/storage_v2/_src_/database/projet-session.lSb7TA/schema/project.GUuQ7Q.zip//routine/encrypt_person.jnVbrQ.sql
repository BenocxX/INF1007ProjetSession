create function encrypt_person() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.firstname = project.encrypt(NEW.firstname);
    NEW.lastname = project.encrypt(NEW.lastname);
    NEW.email = project.encrypt(NEW.email);
    NEW.phone = project.encrypt(NEW.phone);
    RETURN NEW;
END;
$$;

alter function encrypt_person() owner to dev;

