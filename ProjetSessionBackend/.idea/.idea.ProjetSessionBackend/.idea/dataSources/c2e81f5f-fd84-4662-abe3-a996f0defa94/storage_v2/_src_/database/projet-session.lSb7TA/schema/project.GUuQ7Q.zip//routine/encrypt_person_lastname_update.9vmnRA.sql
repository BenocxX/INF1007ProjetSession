create function encrypt_person_lastname_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.lastname = project.encrypt(NEW.lastname);
    RETURN NEW;
END;
$$;

alter function encrypt_person_lastname_update() owner to dev;

