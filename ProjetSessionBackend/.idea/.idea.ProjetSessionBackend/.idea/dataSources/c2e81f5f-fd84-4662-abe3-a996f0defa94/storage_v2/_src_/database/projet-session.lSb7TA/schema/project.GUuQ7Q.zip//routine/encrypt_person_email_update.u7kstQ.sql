create function encrypt_person_email_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.email = project.encrypt(NEW.email);
    RETURN NEW;
END;
$$;

alter function encrypt_person_email_update() owner to dev;

