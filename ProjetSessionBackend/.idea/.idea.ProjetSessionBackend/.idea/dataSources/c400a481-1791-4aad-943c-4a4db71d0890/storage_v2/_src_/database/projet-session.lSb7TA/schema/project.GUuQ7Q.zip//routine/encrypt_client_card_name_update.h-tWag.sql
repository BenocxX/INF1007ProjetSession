create function encrypt_client_card_name_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.card_name = project.encrypt(NEW.card_name);
    RETURN NEW;
END;
$$;

alter function encrypt_client_card_name_update() owner to dev;

