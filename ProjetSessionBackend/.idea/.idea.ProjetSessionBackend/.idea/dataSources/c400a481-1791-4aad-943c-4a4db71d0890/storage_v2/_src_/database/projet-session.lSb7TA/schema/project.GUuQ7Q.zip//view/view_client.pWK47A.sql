create view view_client(client_id, fullname, email, phone, address) as
SELECT c.client_id,
       (project.decrypt(p.firstname) || ' '::text) || project.decrypt(p.lastname) AS fullname,
       project.decrypt(p.email)                                                   AS email,
       project.decrypt(p.phone)                                                   AS phone,
       project.decrypt(c.address::text)                                           AS address
FROM project.client c
         LEFT JOIN project.person p ON c.person_id = p.person_id;

alter table view_client
    owner to dev;

