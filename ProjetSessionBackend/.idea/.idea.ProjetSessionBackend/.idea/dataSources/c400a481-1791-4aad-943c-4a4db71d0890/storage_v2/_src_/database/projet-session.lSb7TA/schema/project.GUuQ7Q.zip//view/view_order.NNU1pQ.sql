create view view_order
            (order_id, client_id, status, fullname, email, phone, payment, tps_value, tvq_value, subtotal, total,
             created_at, updated_at)
as
SELECT o.order_id,
       c.client_id,
       o.status,
       (project.decrypt(p.firstname) || ' '::text) || project.decrypt(p.lastname) AS fullname,
       project.decrypt(p.email)                                                   AS email,
       project.decrypt(p.phone)                                                   AS phone,
       o.payment,
       o.tps_value,
       o.tvq_value,
       o.subtotal,
       o.total,
       o.created_at,
       o.updated_at
FROM project."order" o
         LEFT JOIN project.client c ON o.client_id = c.client_id
         LEFT JOIN project.person p ON c.person_id = p.person_id;

alter table view_order
    owner to dev;

