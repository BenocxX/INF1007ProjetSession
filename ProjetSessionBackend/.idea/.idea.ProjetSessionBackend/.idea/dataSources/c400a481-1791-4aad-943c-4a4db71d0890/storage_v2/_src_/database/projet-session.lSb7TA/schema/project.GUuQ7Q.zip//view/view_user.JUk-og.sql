create view view_user(user_id, fullname, password, email, phone, user_type) as
SELECT u.user_id,
       (project.decrypt(p.firstname) || ' '::text) || project.decrypt(p.lastname) AS fullname,
       u.password,
       project.decrypt(p.email)                                                   AS email,
       project.decrypt(p.phone)                                                   AS phone,
       u.user_type
FROM project."user" u
         LEFT JOIN project.person p ON u.person_id = p.person_id;

alter table view_user
    owner to dev;

