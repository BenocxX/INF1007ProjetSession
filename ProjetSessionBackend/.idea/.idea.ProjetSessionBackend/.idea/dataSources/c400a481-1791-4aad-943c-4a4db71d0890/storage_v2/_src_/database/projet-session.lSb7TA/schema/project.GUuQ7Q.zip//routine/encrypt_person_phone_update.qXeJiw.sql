create function encrypt_person_phone_update() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.phone = project.encrypt(NEW.phone);
    RETURN NEW;
END;
$$;

alter function encrypt_person_phone_update() owner to dev;

