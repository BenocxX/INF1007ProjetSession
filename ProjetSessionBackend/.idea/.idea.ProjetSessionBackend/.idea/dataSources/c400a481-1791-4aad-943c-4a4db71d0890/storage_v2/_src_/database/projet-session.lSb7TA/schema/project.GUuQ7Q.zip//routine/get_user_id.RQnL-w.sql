create function get_user_id() returns integer
    language plpgsql
as
$$
DECLARE
    user_id INT;
BEGIN
    BEGIN
        user_id := current_setting('project.user_id')::integer;
    EXCEPTION
        WHEN OTHERS THEN user_id := null;
    END;
    RETURN user_id;
END;
$$;

alter function get_user_id() owner to dev;

