create function encrypt(plaintext text) returns text
    language plpgsql
as
$$
DECLARE
    encryption_key TEXT;
BEGIN
    -- Will raise error if the encryption_key isn't defined
    encryption_key := 'yaxN62KQXT7snMnALpbEsd/eMxAlnT2gUI5WNxTfX0hbs4bkXir/Jv2sIjYlrR/MaduntmR/mVKtNDOkrOcUIw==';
    RETURN encode(project.pgp_sym_encrypt(plaintext, encryption_key, 'cipher-algo=aes256, s2k-mode=1'::text), 'base64');
END;
$$;

alter function encrypt(text) owner to dev;

