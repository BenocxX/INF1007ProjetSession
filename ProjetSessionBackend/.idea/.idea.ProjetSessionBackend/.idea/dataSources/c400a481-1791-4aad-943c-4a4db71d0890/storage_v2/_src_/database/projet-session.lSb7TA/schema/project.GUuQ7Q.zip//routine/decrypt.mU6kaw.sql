create function decrypt(cipher text) returns text
    language plpgsql
as
$$
DECLARE
    encryption_key TEXT;
BEGIN
    BEGIN

        -- IF the encryption_key isn't defined, do not raise error
        encryption_key := 'yaxN62KQXT7snMnALpbEsd/eMxAlnT2gUI5WNxTfX0hbs4bkXir/Jv2sIjYlrR/MaduntmR/mVKtNDOkrOcUIw==';

        -- If decryption is invalid due to message corruption or wrong key, it will raise an error
        RETURN project.pgp_sym_decrypt(decode(cipher, 'base64')::bytea, encryption_key, 'cipher-algo=aes256, s2k-mode=1'::text)::text;

    EXCEPTION

        -- When a error arise (encryption_key not defined or failed decryption) return default encrypted notice
        WHEN OTHERS THEN RETURN '###ENCRYPTED###';
    END;
END;
$$;

alter function decrypt(text) owner to dev;

