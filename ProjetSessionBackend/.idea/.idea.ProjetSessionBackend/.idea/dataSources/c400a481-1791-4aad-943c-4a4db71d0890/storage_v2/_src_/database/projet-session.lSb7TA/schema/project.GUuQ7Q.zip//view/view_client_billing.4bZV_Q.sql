create view view_client_billing(client_id, card_name, card_number, expiry_date, cvv) as
SELECT c.client_id,
       project.decrypt(c.card_name::text)   AS card_name,
       project.decrypt(c.card_number::text) AS card_number,
       project.decrypt(c.expiry_date::text) AS expiry_date,
       project.decrypt(c.cvv::text)         AS cvv
FROM project.client c;

alter table view_client_billing
    owner to dev;

